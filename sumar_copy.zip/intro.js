const numbers = (a,b) => { 
    return {a,b}
}

module.exports.numbers = numbers;