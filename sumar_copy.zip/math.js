const intro = require('./intro')
const intro2 = require('./intro')

const operacion = require('./suma');
const operacion2 = require('./suma');

console.log(operacion.suma(intro.numbers(3,3)));
console.log(operacion2.suma(intro2.numbers(5,5)));