const suma = function (params) { 
    //console.log(params.a + params.b)
    return params.a + params.b
}

module.exports.suma = suma;
